import fs from 'fs';
import { auth } from '@/lib/auth';
import type { User as SupabaseUser } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

/**
 * This script is used to import users from json file to Better-Auth based Database.
 *
 * change auth.ts to Drizzle adapter for import
 *
 * pnpm exec tsx -r dotenv/config import.ts
 */
type User = SupabaseUser & {
  is_super_admin: boolean;
  raw_user_meta_data: {
    avatar_url: string;
  };
  encrypted_password: string;
  email_confirmed_at: string;
  created_at: string;
  updated_at: string;
  is_anonymous: boolean;
  identities: {
    provider: string;
    identity_data: {
      sub: string;
      email: string;
    };
    created_at: string;
    updated_at: string;
  };
};

const importFromJSONFile = async () => {
  const users = JSON.parse(fs.readFileSync('users.json', 'utf8')) as User[];
  console.log(`Found ${users.length} users`);
  // console.log(`user: ${JSON.stringify(users[1], null, 2)}`);

  const ctx = await auth.$context;
  for (const user of users) {
    if (!user.email) {
      continue;
    }
    console.log(`Migrating user ${user.id}`);
    await ctx.adapter.create({
      model: 'user',
      data: {
        id: user.id,
        email: user.email,
        name: user.email,
        // role: user.is_super_admin ? 'admin' : user.role,
        emailVerified: !!user.email_confirmed_at,
        image: user.raw_user_meta_data.avatar_url,
        createdAt: new Date(user.created_at),
        updatedAt: new Date(user.updated_at),
        // isAnonymous: user.is_anonymous,
      },
    });
    for (const identity of user.identities) {
      // const existingAccounts = await ctx.internalAdapter.findAccounts(user.id);
      if (identity.provider === 'email') {
        // const hasCredential = existingAccounts.find(
        //   (account) => account.providerId === 'credential'
        // );
        const hasCredential = false;
        if (!hasCredential) {
          console.log(
            `- Migrating account (credential) for accountId: ${user.id}`
          );
          await ctx.adapter.create({
            model: 'account',
            data: {
              userId: user.id,
              providerId: 'credential',
              accountId: user.id,
              password: user.encrypted_password,
              createdAt: new Date(user.created_at),
              updatedAt: new Date(user.updated_at),
            },
          });
        }
      }
      const supportedProviders = Object.keys(ctx.options.socialProviders || {});
      if (supportedProviders.includes(identity.provider)) {
        // const hasAccount = existingAccounts.find(
        //   (account) => account.providerId === identity.provider
        // );
        const hasAccount = false;
        if (!hasAccount) {
          console.log(
            `- Migrating account (${identity.provider}) for accountId: ${identity.identity_data?.sub}`
          );
          await ctx.adapter.create({
            model: 'account',
            data: {
              userId: user.id,
              providerId: identity.provider,
              accountId: identity.identity_data?.sub,
              createdAt: new Date(identity.created_at ?? user.created_at),
              updatedAt: new Date(identity.updated_at ?? user.updated_at),
            },
          });
        }
      }
    }
  }
};

importFromJSONFile();
