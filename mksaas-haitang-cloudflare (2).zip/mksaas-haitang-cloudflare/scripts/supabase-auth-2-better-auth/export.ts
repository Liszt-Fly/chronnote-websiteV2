import fs from 'fs';
import { auth } from '@/lib/auth';
import type { User as SupabaseUser } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import type { Pool } from 'pg';
dotenv.config();

/**
 * This script is used to export users from Supabase Database to json file.
 *
 * change auth.ts to Pool adapter for export
 *
 * pnpm exec tsx -r dotenv/config export.ts
 */
type User = SupabaseUser & {
  is_super_admin: boolean;
  raw_user_meta_data: {
    avatar_url: string;
  };
  encrypted_password: string;
  email_confirmed_at: string;
  created_at: string;
  updated_at: string;
  is_anonymous: boolean;
  identities: {
    provider: string;
    identity_data: {
      sub: string;
      email: string;
    };
    created_at: string;
    updated_at: string;
  };
};

const exportFromSupabase = async () => {
  const ctx = await auth.$context;
  const db = ctx.options.database as Pool;
  const users = await db
    .query(`
			SELECT
				u.*,
				COALESCE(
					json_agg(
						i.* ORDER BY i.id
					) FILTER (WHERE i.id IS NOT NULL),
					'[]'::json
				) as identities
			FROM auth.users u
			LEFT JOIN auth.identities i ON u.id = i.user_id
			GROUP BY u.id
		`)
    .then((res) => res.rows as User[]);
  console.log(`Found ${users.length} users`);
  // console.log(`user: ${JSON.stringify(users[1], null, 2)}`);

  // export users to json file
  fs.writeFileSync('users.json', JSON.stringify(users, null, 2));
};

exportFromSupabase();
