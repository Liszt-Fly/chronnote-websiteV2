'use server';

import { getDb } from '@/db';
import { table_users_like_works, table_works } from '@/db/schema';
import { getSession } from '@/lib/server';
import { and, eq } from 'drizzle-orm';
import { createSafeActionClient } from 'next-safe-action';
import { z } from 'zod';

const actionClient = createSafeActionClient();

const favoriteSchema = z.object({
  workId: z.number().int().min(1, { message: 'workId is required' }),
});

export const addFavoriteAction = actionClient
  .schema(favoriteSchema)
  .action(async ({ parsedInput }) => {
    const { workId } = parsedInput;
    const session = await getSession();
    if (!session) {
      return { success: false, error: 'Unauthorized' };
    }
    const userId = session.user.id;
    // check if already exists
    const db = await getDb();
    const exist = await db
      .select()
      .from(table_users_like_works)
      .where(
        and(
          eq(table_users_like_works.user_id, userId),
          eq(table_users_like_works.works_id, workId)
        )
      )
      .limit(1);
    if (exist.length > 0) {
      return { success: true, isFavorite: true };
    }
    // get work info
    const works = await db
      .select({
        id: table_works.id,
        title: table_works.title,
        author: table_works.author,
        dynasty: table_works.dynasty,
      })
      .from(table_works)
      .where(eq(table_works.id, workId))
      .limit(1);
    if (works.length === 0) {
      return { success: false, error: 'Work not found' };
    }
    const work = works[0];
    try {
      await db.insert(table_users_like_works).values({
        works_id: work.id,
        works_title: work.title || '',
        works_author: work.author || '',
        works_dynasty: work.dynasty || '',
        user_id: userId,
      });
      return { success: true, isFavorite: true };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Something went wrong',
      };
    }
  });

export const removeFavoriteAction = actionClient
  .schema(favoriteSchema)
  .action(async ({ parsedInput }) => {
    const { workId } = parsedInput;
    const session = await getSession();
    if (!session) {
      return { success: false, error: 'Unauthorized' };
    }
    const userId = session.user.id;
    try {
      const db = await getDb();
      await db
        .delete(table_users_like_works)
        .where(
          and(
            eq(table_users_like_works.user_id, userId),
            eq(table_users_like_works.works_id, workId)
          )
        );
      return { success: true, isFavorite: false };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Something went wrong',
      };
    }
  });

export const checkFavoriteAction = actionClient
  .schema(favoriteSchema)
  .action(async ({ parsedInput }) => {
    const { workId } = parsedInput;
    const session = await getSession();
    if (!session) {
      return { success: false, error: 'Unauthorized', isFavorite: false };
    }
    const userId = session.user.id;
    try {
      const db = await getDb();
      const exist = await db
        .select()
        .from(table_users_like_works)
        .where(
          and(
            eq(table_users_like_works.user_id, userId),
            eq(table_users_like_works.works_id, workId)
          )
        )
        .limit(1);
      return { success: true, isFavorite: exist.length > 0 };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Something went wrong',
        isFavorite: false,
      };
    }
  });
