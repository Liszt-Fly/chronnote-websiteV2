import { BlogGridSkeleton } from '@/components/blog/blog-grid';

export default function Loading() {
  return <BlogGridSkeleton />;
}
