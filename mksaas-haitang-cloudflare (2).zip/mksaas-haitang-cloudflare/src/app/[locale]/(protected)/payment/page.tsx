import { PaymentCard } from '@/components/payment/payment-card';

export default function PaymentPage() {
  return <PaymentCard />;
}
