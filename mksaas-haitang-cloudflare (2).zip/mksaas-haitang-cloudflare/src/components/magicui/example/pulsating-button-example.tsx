import { PulsatingButton } from "@/components/magicui/pulsating-button";

export function PulsatingButtonDemo() {
  return <PulsatingButton>Join Affiliate Program</PulsatingButton>;
}
