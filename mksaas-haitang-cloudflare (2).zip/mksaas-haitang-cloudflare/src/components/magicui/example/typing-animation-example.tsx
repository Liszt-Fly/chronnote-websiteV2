import { TypingAnimation } from "@/components/magicui/typing-animation";

export function TypingAnimationDemo() {
  return <TypingAnimation>Typing Animation</TypingAnimation>;
}
