import { RainbowButton } from "@/components/magicui/rainbow-button";

export function RainbowButtonDemo() {
  return <RainbowButton>Get Unlimited Access</RainbowButton>;
}
