import { SparklesText } from "@/components/magicui/sparkles-text";

export function SparklesTextDemo() {
  return <SparklesText>Magic UI</SparklesText>;
}
