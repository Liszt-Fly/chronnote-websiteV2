import { InteractiveHoverButton } from "@/components/magicui/interactive-hover-button";

export function InteractiveHoverButtonDemo() {
  return <InteractiveHoverButton>Hover Me</InteractiveHoverButton>;
}
