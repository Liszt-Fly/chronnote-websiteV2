import { RippleButton } from "@/components/magicui/ripple-button";

export function RippleButtonDemo() {
  return <RippleButton rippleColor="#ADD8E6">Click me</RippleButton>;
}
