import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
} from '@/components/ui/card';
import type { Quote } from '@/types/db';
import Link from 'next/link';

interface QuoteCardProps {
  quote: Quote;
}

export default function QuoteCard({ quote }: QuoteCardProps) {
  const workId = quote.work_id;
  const workContent = quote.quote;
  const workAuthor = quote.author;
  const workDynasty = quote.dynasty;
  const workTitle = quote.work_title;

  return (
    <Link href={`/works/${workId}`}>
      <Card className="cursor-pointer bg-transparent h-full transition-all duration-300 ease-in-out hover:border-primary hover:shadow-lg hover:shadow-primary/20">
        <CardContent>
          <p className="line-clamp-2 leading-relaxed">{workContent}</p>
        </CardContent>
        <CardFooter className="flex gap-1">
          <span className="text-sm text-muted-foreground line-clamp-1">
            {workAuthor}
          </span>
          <span className="text-sm text-muted-foreground line-clamp-1">
            《{workTitle}》
          </span>
        </CardFooter>
      </Card>
    </Link>
  );
}
