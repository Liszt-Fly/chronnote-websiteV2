import { Loader2Icon } from 'lucide-react';

export default function Loading() {
  return <Loader2Icon className="my-32 mx-auto size-6 animate-spin" />;
}
